/**
 * Décrivez votre interface I ici.
 *
 * @author  (votre nom)
 * @version (un numéro de version ou une date)
 */

public interface I
{
    /**
     * Exemple d'entête de méthode - remplacez ce commentaire par le vôtre
     *
     * @param  y    le paramètre de cette méthode
     * @return        le résultat retourné par exempleDeMethode
     */
    int exempleDeMethode(int y);
}
