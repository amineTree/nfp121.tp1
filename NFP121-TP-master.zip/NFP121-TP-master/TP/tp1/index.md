
<style type="text/css">
        body {
            background: #E5DED6;
            background-color: #fff;
            color: #333333;
            font-size: 14px;
            font-family: Verdana, Arial;
        }

        table {
            font-size: 20px;
            border-color: #808080;
            border-style: solid;
            border-width: 1px;
        }

        h2 {
            color: #C1002A;
            font-family: Verdana, Arial;
            font-size: 30px;
            font-weight: bold;
        }

        h3 {
            color: #C1002A;
            font-family: Verdana, Arial;
            font-size: 20px;
            font-weight: bold;
        }
        
        hr {
            margin: 15px 0 15px 0;
        }
</style>

## NFP 121 - TP1
## L'environnement de programmation BlueJ

<table>
        <tr>
            <td>Nom
            </td>
            <td>...
            </td>
        </tr>
        <tr>
            <td>Prénom
            </td>
            <td>...
            </td>
        </tr>
        <tr>
            <td>Identifiant
            </td>
            <td>...
            </td>
        </tr>
</table>

### Question 1 :

    Votre réponse...

### Question 2

    Votre réponse...


### Question 3 :
    
    Votre réponse...


### Conclusion, biliographie et remarques :

<i style="font-size:12px;">... Une seule page html, limitez le nombre de clics</i>
    
</body>
</html>
