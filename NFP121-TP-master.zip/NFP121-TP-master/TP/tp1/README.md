------------------------------------------------------------------------
Ceci est le fichier LISEZMOI (README) du projet.  Décrivez-y votre projet. Dites au lecteur (qui ne sait rien du projet) ce qu'il a besoin de savoir.Au minimum, remplissez cette description :
------------------------------------------------------------------------

## TITRE DU PROJET :
## BUT POURSUIVI :
## VERSION ou DATE :
## COMMENT INVOQUER CE PROJET :
## AUTEURS :
## INSTRUCTIONS À L'USAGER :
