
---
titre: pré-inscription en NFP121 aux TP préfixer Nom et Mot de passe par LIB_
---

# pré-inscription en NFP121 aux TP  à <a href="./index.html">JNEWS</a> pour tous les auditeurs du Cnam, centre associés et FOAD


## Si vous n'êtes pas sur cette [liste](http://jfod.cnam.fr/jnews/interrogation/listeDesInscrits.html?ue=NFP121&pre=on) alors pré-inscrivez-vous


<form method="POST" action="http://jfod.cnam.fr/jnews/pre_inscription.html?ue=NFP121">

<a title="Évitez les caractères accentués, quote, espace, ..." style="text-decoration: none;">Nom<sup>1</sup></a> : 
<input type="text" size="20" name="nom" value="LIB_????">
<a title="Exemple LIB_1000f" style="text-decoration: none;">Mot de passe<sup>1,2,3</sup></a>
<input type="text" size="20" name="matricule" value="LIB_????">
<br/>
votre mail<sup>4</sup> : <input type="text" size="30" name="e_mail" value="????@isae.edu.lb">
<input type="submit" name="B1" value="pré-inscription">
<hr/>
<sup>1</sup> **En évitant les caractères accentués, quote, espace, tiret, spéciaux (@,!,§,...) ... **
    
<br/><sup>2</sup>Le mot de passe: le numéro ID Cnam Liban; se trouve sur votre carte d'auditeur Cnam, à défaut un mot de passe de votre choix préfixé par LIB_. http://si.isae.edu.lb 

<br/><sup>3</sup>préfixer le matricule par et le mot de passe par <b>LIB_</b>

    exemple : un auditeur inscrit au Cnam Liban dont le numéro est 1000 f, se pré-inscrira avec le mot de passe LIB_1000f
    En cas de doute, consultez l'enseignant de votre centre pour le préfixe à adopter.

<br/><sup>4</sup> Un courriel/accusé d'inscription vous sera envoyé (devrait vous être envoyé...).

</form>


