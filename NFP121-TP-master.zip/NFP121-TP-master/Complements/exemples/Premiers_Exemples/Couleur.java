
/**
 * Enumeration Couleur - quelques couleur
 *
 * @author (votre nom)
 * @version (numéro de version ou date)
 */
public enum Couleur
{
    ROUGE, VERT, BLEU, NOIR, BLANC
}
