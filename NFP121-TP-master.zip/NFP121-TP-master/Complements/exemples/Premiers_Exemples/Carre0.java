
/**
 * Décrivez votre classe Carre ici.
 *
 * @author (votre nom)
 * @version (un numéro de version ou une date)
 */
public class Carre0 extends PolygoneRegulier
{
    /**
     * Constructeur Carre
     * @param l : talle du coté
     */
    public Carre0(int l) {
        super(l,4);
    }
}
