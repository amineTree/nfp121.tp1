
/**
 * 
 * @author TD NFP121
 * @version v 0.007
 */
public class ListeVideException extends Exception {

}
